﻿public class Maldonado
{
    int numero;
    string cadena;
    int dosnumero;

    public Maldonado(int numero, string cadena, int dosnumero)
    {
        this.numero = numero;
        this.cadena = cadena;
        this.dosnumero = dosnumero;
    }
    void show()
    {
        Console.WriteLine(this.numero);
        Console.WriteLine(this.cadena);
        Console.WriteLine(this.dosnumero);
    }
    public void IngresarValores()
    {
        Console.Write("Ingrese un número: ");
        numero = Int32.Parse(Console.ReadLine());
        Console.Write("Ingrese una cadena: ");
        cadena = Console.ReadLine();
        Console.Write("Ingrese un segundo número: ");
        dosnumero = Int32.Parse(Console.ReadLine());
    }
    public static void Main()
    {
        Maldonado objetoProgram = new Maldonado(0, "cero", 0);
        int opcion;

        do
        {
            Console.WriteLine("Menu:");
            Console.WriteLine("1. Ingreso de valores");
            Console.WriteLine("2. Mostrar valores");
            Console.WriteLine("3. Salir del programa");
            Console.Write("Ingrese una opción: ");
            opcion =Int32.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    objetoProgram.IngresarValores();
                    break;
                case 2:
                    objetoProgram.show();
                    break;
                case 3:
                    Console.WriteLine("Cerrado");
                    break;
                default:
                    Console.WriteLine("Opción inválida. Inténtelo de nuevo.");
                    break;
            }
        } while (opcion != 3);
    }
}