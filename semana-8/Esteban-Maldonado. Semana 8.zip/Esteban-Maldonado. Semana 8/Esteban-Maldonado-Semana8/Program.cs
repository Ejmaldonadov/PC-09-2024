﻿ Console.WriteLine("Ingrese un número entero positivo no mayor a 6 cifras:");
 int n1 = Int32.Parse(Console.ReadLine());
{
    if (n1 < 0 || n1 >999999)
        {
            Console.WriteLine("El número ingresado no es válido");
        }

        else if (EsPrimo(n1))
        {
            Console.WriteLine("El número ingresado es primo.");
        }
             else
              {
                  Console.WriteLine("El número ingresado no es primo.");
              }
}
static bool EsPrimo(int n1)
    {
        if (n1 <= 1)
        {
            return false;
        }

        if (n1 <= 3)
        {
            return true;
        }

        if (n1 % 2 == 0 || n1 % 3 == 0)
        {
            return false;
        }

        for (int i = 5; i * i <= n1; i += 6)
        {
            if (n1 % i == 0 || n1 % (i + 2) == 0)
            {
                return false;
            }
        }

        return true;
    }
Console.ReadKey();  