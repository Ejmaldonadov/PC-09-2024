﻿using System.Diagnostics.CodeAnalysis;

namespace semana_12
{
    class Program
    {
        static void Main()
        {
            menu();
        }
        static void menu()
        {
            int num1;
            int num2;

            Console.WriteLine("Ingrese el primero número:");
            num1 = Int32.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese el segundo número:");
            num2 = Int32.Parse(Console.ReadLine());

            Console.WriteLine("Semana_12: seleccione una opción: ");
            Console.WriteLine(" a) Sumar");
            Console.WriteLine(" b) Multiplicar");
            Console.WriteLine(" c) Restar");

            char opcion = Console.ReadLine().ToLower()[0];
            switch (opcion)
            {
                case 'a':
                    int suma = 0;
                    suma = num1 + num2;
                        Console.WriteLine("El resultado de la suma es de " +suma);
                    break;

                case 'b':
                    int multi = 0;
                    multi = num1 * num2;
                    Console.WriteLine("El resultado de la multiplicación es de " + multi);
                    break;

                case 'c':
                    int resta = 0;
                    resta = num1 - num2;
                    Console.WriteLine("El resultado de la resta es de" + resta);

                    break;

                default:
                    Console.WriteLine("La opción seleccionada no es válida.");
                    break;
            }
        }
    }
}