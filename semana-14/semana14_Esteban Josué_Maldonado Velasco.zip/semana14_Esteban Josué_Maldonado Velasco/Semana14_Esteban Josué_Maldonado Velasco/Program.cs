﻿namespace Semana14
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numeros = new int[12];
            for (int i = 0; i < 12; i++)
            {
                Console.Write($"Ingrese el número {i + 1}: ");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            }
            int opcion;
            do
            {
                Console.WriteLine("MENU:");
                Console.WriteLine("1. Sumar números");
                Console.WriteLine("2. Promedio");
                Console.WriteLine("3. Menor a mayor");
                Console.WriteLine("4. Mayor a menor");
                Console.WriteLine("5. Cambiar tamaño");
                Console.WriteLine("6. Cerrar");
                Console.Write("Selección: ");
                opcion = Convert.ToInt32(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        SUMA(numeros);
                        break;
                    case 2:
                        PROMEDIO(numeros);
                        break;
                    case 3:
                        MENORMAYOR(numeros);
                        break;
                    case 4:
                        MAYORMENOR(numeros);
                        break;
                    case 5:
                        CambiarTamaño(numeros);
                        break;
                    case 6:
                        Console.WriteLine("Programa cerrado.");
                        break;
                    default:
                        Console.WriteLine("Opción inválida.");
                        break;
                }
            } while (opcion != 6);
        }

        static void SUMA(int[] numeros)
        {
            int suma = 0;
            foreach (int num in numeros)
            {
                suma += num;
            }
            Console.WriteLine("La suma total es de:" + suma);
        }
        static void PROMEDIO(int[] numeros)
        {
            int suma = 0;
            foreach (int num in numeros)
            {
                suma += num;
            }
            double promedio = (double)suma / numeros.Length;
            Console.WriteLine("El promedio de los números del arreglo es:" + promedio);
        }
        static void MENORMAYOR(int[] numeros)
        {
            Console.WriteLine("Números ordenado de menor a mayor: ");
            Array.Sort(numeros);
            foreach (var pallet in numeros)
            {
                Console.WriteLine($" {pallet}");
            }
        }
        static void MAYORMENOR(int[] numeros)
        {
            Console.WriteLine("Números ordenados de mayor a menor:");
            Array.Sort(numeros);
            Array.Reverse(numeros);
            foreach (var pallet in numeros)
            {
                Console.WriteLine($" {pallet}");
            }
        }
        static void CambiarTamaño(int[] numeros)
        {
            Array.Resize(ref numeros, numeros.Length + 2);
            for (int i = numeros.Length - 2; i < numeros.Length; i++)
            {
                Console.Write($"Ingrese el valor para el número {i + 1}: ");
                numeros[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("Posiciones adicionales:");
            foreach (int num in numeros)
            {
                Console.Write(num + " ");
            }
            Console.WriteLine();
        }
    }
}